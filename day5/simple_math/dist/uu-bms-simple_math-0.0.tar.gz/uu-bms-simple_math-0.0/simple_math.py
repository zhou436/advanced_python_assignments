def simple_math():
    ''' Just a simple test here '''
    a = 1

