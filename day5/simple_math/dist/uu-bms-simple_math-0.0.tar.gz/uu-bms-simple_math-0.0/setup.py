from setuptools import setup

setup(name='uu-bms-simple_math',
    version='0.0',
    description='Nothing',
    author='Yijun Zhou',
    author_email='yijun.zhou@angstrom.uu.se',
    license='BSD',
    py_modules=['simple_math'],
    packages=[])